# Patent Drafting Practice Library

This clean, expanded edition contains nine polished learning artifacts. It preserves the five user-facing guides and worksheets from the supplied archive and adds four companion Word guides that use the same three-page design: framework, worksheet, quick reference, common traps, and final checklist.

## Start here

Open `00 Start Here/Patent_Drafting_Practice_Library_Index.docx`. It maps common drafting tasks to the narrowest useful guide and provides a reusable drafting-session worksheet.

## Library map

- `Claims/Independent Claims/Independent_Claim_Outline_Guide.docx`
  - Select a claim boundary and define the minimum complete inventive combination.
- `Claims/Dependent Claims/Dependent_Claim_Outline_Guide.docx`
  - Build supported fallback positions, sibling branches, and deliberate chains.
- `Claims/Claim-Set Strategy/Claim_Set_Strategy_and_Prosecution_Guide.docx`
  - Compare amendment and separate-root choices when a dependent position appears allowable.
- `Specification/Application Architecture/Application_Architecture_and_Workflow_Guide.docx`
  - Move from source discovery to claims-aligned application sections.
- `Specification/Summary of the Invention/Summary_of_the_Invention_Guide.docx`
  - Translate claim architecture into readable specification prose.
- `Language/Drafting_Language_and_Optionality_Guide.docx`
  - Choose direct, optional, capability, and claim wording deliberately.
- `Figures and Detailed Description/figure_narrative_high_level_guide.pdf`
  - Turn a figure into a structured technical narrative.
- `Figures and Detailed Description/cabinet_system_template_with_guide.xlsx`
  - Use one completed feature-map example and reusable blank worksheets.

## Suggested path

1. Start with the library index and application workflow.
2. Build the invention thesis, terminology sheet, and feature or relationship map.
3. Draft the independent-claim spine.
4. Build dependent fallback branches.
5. Draft the filing Summary from the substantially established claim architecture.
6. Use the figure guide and workbook to develop the Detailed Description.
7. Run the language and cross-application review checks.
8. Use the prosecution guide only with the complete Office-action record and practitioner review.

## Scope and use

These materials are educational U.S. utility-patent drafting aids, not legal advice. They separate official legal or procedural baselines from context-sensitive practice suggestions. Application type, technology, client objectives, filing strategy, prosecution posture, and current law can change the appropriate approach. Matter-specific work should be reviewed by a registered patent practitioner.

The figure example is hypothetical training material. The cleaned distribution excludes generation scripts, internal paths, inspection logs, duplicate working copies, stale renders, and preview images from the supplied archive.

## Primary official references

- USPTO MPEP Chapter 600, Parts, Form, and Content of Application: https://www.uspto.gov/web/offices/pac/mpep/mpep-0600.html
- USPTO MPEP 608, Disclosure: https://www.uspto.gov/web/offices/pac/mpep/s608.html
- USPTO MPEP 707, Examiner's Letter or Action: https://www.uspto.gov/web/offices/pac/mpep/s707.html
- USPTO MPEP 2163, Written Description: https://www.uspto.gov/web/offices/pac/mpep/s2163.html
- USPTO MPEP 2173, Claim Clarity: https://www.uspto.gov/web/offices/pac/mpep/s2173.html
- 35 U.S.C. 112: https://uscode.house.gov/view.xhtml?req=granuleid:USC-prelim-title35-section112&num=0&edition=prelim

Prepared August 25, 2026.
